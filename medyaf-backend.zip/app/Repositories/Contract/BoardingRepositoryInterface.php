<?php

        namespace App\Repositories\Contract;

        interface BoardingRepositoryInterface
        {

        }
        