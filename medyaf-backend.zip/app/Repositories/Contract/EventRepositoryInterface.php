<?php

        namespace App\Repositories\Contract;

        interface EventRepositoryInterface
        {

        }
        