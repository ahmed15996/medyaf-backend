<?php

        namespace App\Repositories\Contract;

        interface StaticPageRepositoryInterface
        {

        }
        