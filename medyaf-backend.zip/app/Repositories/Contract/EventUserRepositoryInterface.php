<?php

        namespace App\Repositories\Contract;

        interface EventUserRepositoryInterface
        {

        }
        