<?php $__env->startSection('title'); ?>
  <?php echo e(__('models.party_details')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/lity@2.4.1/dist/lity.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0"><?php echo e(__('models.party_details')); ?></h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.parties.index')); ?>"><?php echo e(__('models.parties')); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e(__('models.party_details')); ?></li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class="row">
    <div class="col-xxl-3">
        <div class="card">
            <div class="card-body text-center">
                <h6 class="card-title mb-3 flex-grow-1 text-start"><?php echo e(__('models.time')); ?></h6>
                <div class="mb-2">
                    <lord-icon src="https://cdn.lordicon.com/kbtmbyzy.json" trigger="loop" colors="primary:#405189,secondary:#02a8b5" style="width:90px;height:90px"></lord-icon>
                </div>
                <h3 class="mb-1 text-info"><?php echo e(Carbon\Carbon::parse($party->time)->format('h:i A')); ?></h3>
                <h2 class="mb-3 text-info"><?php echo e($party->date); ?></h2>

            </div>
        </div>
        <!--end card-->
        <div class="card mb-3">
            <div class="card-body">

                <div class="table-card">
                    <table class="table mb-0">
                        <tbody>
                            <tr>
                                <td class="fw-medium"><?php echo e(__('models.party_name')); ?></td>
                                <td><?php echo e($party->name); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-medium"><?php echo e(__('models.code')); ?></td>
                                <td><?php echo e($party->code); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-medium"><?php echo e(__('models.img')); ?></td>
                                <td>
                                    <a href="#" data-lity data-lity-target="<?php echo e(asset('storage/' . $party->img)); ?>">
                                        <img src="<?php echo e(asset('storage/' . $party->img)); ?>" alt="<?php echo e($party->name); ?>" class="avatar-xl rounded-circle shadow test-popup-link">
                                    </a>

                                </td>
                            </tr>
                            <tr>
                                <td class="fw-medium"><?php echo e(__('models.date')); ?></td>
                                <td><?php echo e($party->date); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-medium"><?php echo e(__('models.time')); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($party->time)->format('h:i A')); ?></td>
                            </tr>
                            <tr>
                                <td class="fw-medium"><?php echo e(__('models.location')); ?></td>
                                <td><?php echo e($party->location); ?></td>
                            </tr>

                        </tbody>
                    </table>
                    <!--end table-->
                </div>
            </div>
        </div>
        <!--end card-->
        <div class="card mb-3">
            <div class="d-grid gap-2" >
                <a href="" class="btn btn-success waves-effect waves-light btn-block add-input-value-color"><?php echo e(__('models.party_users')); ?></a>
            </div>
            <div class="card-body">
                <div class="listjs-table" id="customerList">
                    <div class="row g-4 mb-3">

                    </div>

                    <div class="table-responsive table-card mt-3 mb-1">
                        <table class="table align-middle table-nowrap" id="party_users_table">
                            <thead class="table-light">
                                <tr>
                                    <th class="sort"><?php echo e(__('models.name')); ?></th>
                                    <th class="sort"><?php echo e(__('models.sur_name')); ?></th>
                                    <th class="sort"><?php echo e(__('models.phone')); ?></th>
                                    <th class="sort"><?php echo e(__('models.count')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="list form-check-all">


                            </tbody>
                        </table>






                </div>
            </div><!-- end card -->
        </div>
        <!--end card-->




        <div class="col-md-12 col-12 mb-3">
            <div class="d-flex col-12 flex-column mb-7 fv-row fv-plugins-icon-container" style="height:100vh">

                <div id="map" style="height: 100%;width: 100%;">
            </div>
        </div>


    </div>

</div>
<!--end row-->




<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/lity@2.4.1/dist/lity.min.js"></script>

    <script>
        var table =  $('#party_users_table').DataTable({
            processing     : true,
            serverSide     : true ,
            ordering       : false ,
            iDisplayLength : 10 ,
            lengthMenu     : [
                    [10 , 50 , 100 ,  -1] ,
                    [10 , 50 , 100 ,  'All'] ,
            ] ,
            ajax: {
                url: "<?php echo e(route('admin.get-party-users')); ?>",
                type: "GET",
                data: {
                    party_id: <?php echo e($party->id); ?>

                }
            },
            columns: [

                {
                    data : 'name' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,



                {
                    data : 'sur_name' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data : 'phone' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data : 'count' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,



            ]
        });



    </script>

<?php echo $__env->make('dashboard.backend.parties.mab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/parties/show.blade.php ENDPATH**/ ?>