<?php if (isset($component)) { $__componentOriginale21568ead3521c9c5905956976bc5d60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale21568ead3521c9c5905956976bc5d60 = $attributes; } ?>
<?php $component = App\View\Components\Hidden::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hidden'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Hidden::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country ? $country->id : '')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale21568ead3521c9c5905956976bc5d60)): ?>
<?php $attributes = $__attributesOriginale21568ead3521c9c5905956976bc5d60; ?>
<?php unset($__attributesOriginale21568ead3521c9c5905956976bc5d60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale21568ead3521c9c5905956976bc5d60)): ?>
<?php $component = $__componentOriginale21568ead3521c9c5905956976bc5d60; ?>
<?php unset($__componentOriginale21568ead3521c9c5905956976bc5d60); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.name_ar')).'','name' => 'name_ar','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country ? $country->name_ar : '' )]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.name_en')).'','name' => 'name_en','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($country ? $country->name_en : '' )]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/countries/_inputs.blade.php ENDPATH**/ ?>