<?php $__env->startSection('title'); ?>
  <?php echo e(__('models.us')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="col-xxl-12">
    <div class="card">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0"><?php echo e(__('models.us')); ?></h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active"><?php echo e(__('models.us')); ?></li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="card-body">
            <div class="live-preview">

                <form class="row g-3 needs-validation" method="POST" action="<?php echo e(route('admin.update-us')); ?>" enctype="multipart/form-data" novalidate>
                    <?php echo method_field('PUT'); ?>

                    <?php echo csrf_field(); ?>

                    <?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.title_ar')).'','name' => 'title_ar','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($us->title_ar)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.title_en')).'','name' => 'title_en','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($us->title_en)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $attributes; } ?>
<?php $component = App\View\Components\Textarea::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.desc_ar')).'','name' => 'desc_ar','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($us->desc_ar),'type' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $attributes = $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $attributes; } ?>
<?php $component = App\View\Components\Textarea::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Textarea::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.desc_en')).'','name' => 'desc_en','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($us->desc_en),'type' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $attributes = $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>


                    <div class="col-12">
                        <button class="btn btn-primary" type="submit"><?php echo e(__('models.save')); ?></button>
                    </div>
                </form>
            </div>
        </div>
</div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('dashboard/assets/js/preview-image.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/statics/us.blade.php ENDPATH**/ ?>