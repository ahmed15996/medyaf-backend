
<?php
    $contact = App\Models\ContactUs::where('id' , $id)->first();
?>

<?php echo e(\Illuminate\Support\Str::limit($contact->msg , 10 , '...')); ?>

<a href="#" data-bs-toggle="modal" data-bs-target="#exampleModalScrollable<?php echo e($contact->id); ?>"> <?php echo e(__('models.see_more')); ?> </a>

<div class="modal fade" id="exampleModalScrollable<?php echo e($contact->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalScrollableTitle"><?php echo e(__('models.contact_us')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                <h6 class="fs-15"><?php echo e(__('models.msg')); ?></h6>
                <div class="d-flex">
                    <div class="flex-shrink-0">
                        <i class="ri-checkbox-circle-fill text-success"></i>
                    </div>
                    <textarea cols="150" rows="12"><?php echo e($contact->msg); ?></textarea>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/contacts/msg.blade.php ENDPATH**/ ?>