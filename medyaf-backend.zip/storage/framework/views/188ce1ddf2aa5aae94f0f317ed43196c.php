
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
     'label' , 'value' , 'color' , 'route' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
     'label' , 'value' , 'color' , 'route' => ''
]); ?>
<?php foreach (array_filter(([
     'label' , 'value' , 'color' , 'route' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>




<div class="col-xl-4 col-md-6">
    <!-- card -->
    <div class="card card-animate">
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1 overflow-hidden">
                    <p class="text-uppercase fw-medium text-muted text-truncate mb-0"> <?php echo e($label); ?></p>
                </div>

            </div>
            <div class="d-flex align-items-end justify-content-between mt-4">
                <div>
                    <h4 class="fs-22 fw-semibold ff-<?php echo e($color); ?> mb-4"><span class="counter-value" data-target="<?php echo e($value); ?>">0</span></h4>
                    <a href="$route" class="text-decoration-underline"><?php echo e($label); ?></a>
                </div>
                <div class="avatar-sm flex-shrink-0">
                    <span class="avatar-title bg-info rounded fs-3">
                        <i class=" bx bx-registered"></i>
                    </span>
                </div>
            </div>
        </div><!-- end card body -->
    </div><!-- end card -->
</div>

<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/statics.blade.php ENDPATH**/ ?>