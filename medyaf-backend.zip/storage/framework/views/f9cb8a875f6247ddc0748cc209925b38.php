<?php $__env->startSection('title'); ?>
   <?php echo e(__('models.parties')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"></h4>
            </div><!-- end card header -->

            <div class="card-body">
                <div class="listjs-table" id="customerList">
                    <div class="row g-4 mb-3">

                        <?php if (isset($component)) { $__componentOriginalbf566fc26595b9cc6779e170beef8a5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbf566fc26595b9cc6779e170beef8a5a = $attributes; } ?>
<?php $component = App\View\Components\Select::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Select::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'user_id','label' => ''.e(__('models.users')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users->pluck('name' , 'id')),'type' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $attributes = $__attributesOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__attributesOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a)): ?>
<?php $component = $__componentOriginalbf566fc26595b9cc6779e170beef8a5a; ?>
<?php unset($__componentOriginalbf566fc26595b9cc6779e170beef8a5a); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $attributes; } ?>
<?php $component = App\View\Components\OrderBy::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('order-by'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OrderBy::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'created_id','label' => ''.e(__('models.order_by')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['asc' => 'الأقدم', 'desc' => 'الأحدث'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $attributes = $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $component = $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '4','name' => 'date','value' => '','type' => 'date','label' => ''.e(__('models.date')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
                    </div>

                    <div class="table-responsive table-card mt-3 mb-1">
                        <table class="table align-middle table-nowrap" id="party_table">
                            <thead class="table-light">
                                <tr>

                                    <th class="sort"><?php echo e(__('models.party_name')); ?></th>
                                    <th class="sort"><?php echo e(__('models.img')); ?></th>
                                    <th class="sort"><?php echo e(__('models.date')); ?></th>
                                    <th class="sort"><?php echo e(__('models.time')); ?></th>
                                    <th class="sort"><?php echo e(__('models.code')); ?></th>
                                    <th class="sort"><?php echo e(__('models.owner')); ?></th>
                                    <th class="sort" ><?php echo e(__('models.action')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="list form-check-all">


                            </tbody>
                        </table>







                    </div>
            </div><!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('dashboard/assets/js/custom-delete.js')); ?>"></script>

    <script>
        var table =  $('#party_table').DataTable({
            processing     : true,
            serverSide     : true ,
            ordering       : false ,
            iDisplayLength : 10 ,
            lengthMenu     : [
                    [10 , 50 , 100 ,  -1] ,
                    [10 , 50 , 100 ,  'All'] ,
            ] ,
            ajax: {
                url: "<?php echo e(route('admin.get-parties')); ?>",
                data: function(d) {
                    d.order_by = $('#created_id').val();
                    d.date = $('#date').val();

                }
            },
            columns: [


                {
                    data : 'name' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data: 'img',
                    render: function (data, type, full, meta) {
                        return '<img src="' + '<?php echo e(asset("storage/")); ?>' + '/' + data + '" alt="Image" class="me-3 rounded-circle avatar-md p-2 bg-light" >';
                    } ,
                    searchable: false,

                },


                {
                    data : 'date' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data : 'time' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data : 'code' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data : 'user' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,


                {
                    data : 'action' ,
                    searchable: false,
                } ,



            ]
        });

        $('#user_id').change(function(){
            table.column(5).search($(this).val()).draw();
        });
        $('#created_id').on('change', function(e) {
            console.log($(this).val());
            table.draw();
        });
        $('#date').on('change', function(e) {
            console.log($(this).val());
            table.draw();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/parties/index.blade.php ENDPATH**/ ?>