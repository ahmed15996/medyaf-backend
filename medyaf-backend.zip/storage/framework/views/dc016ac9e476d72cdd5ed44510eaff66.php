<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([

    'label' , 'name' , 'id'=> '' , 'value'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([

    'label' , 'name' , 'id'=> '' , 'value'
]); ?>
<?php foreach (array_filter(([

    'label' , 'name' , 'id'=> '' , 'value'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<div class="col-md-6 col-12 mb-3">
    <label for="<?php echo e($id ? $id : 'formFile'); ?>" class="form-label"><?php echo e($label); ?></label>
    <input class="form-control image" type="file" id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>" >

    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger">
            <small class="errorTxt"><?php echo e($message); ?></small>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group prev">
    <img src="<?php echo e($value ? asset('storage/' . $value) : ''); ?>" style="width: 100px" class="img-thumbnail preview-<?php echo e($id); ?>" alt="">
</div>
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/image.blade.php ENDPATH**/ ?>