<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Copyright .
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Produced by  <a href="https://linkdevelopment.sa/" target="blank">Link Development</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/layouts/footer.blade.php ENDPATH**/ ?>