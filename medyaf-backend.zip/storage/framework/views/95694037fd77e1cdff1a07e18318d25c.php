<?php $__env->startSection('title'); ?>
   <?php echo e(__('models.roles')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><?php echo e(__('models.add_edit_remove')); ?></h4>
            </div><!-- end card header -->

            <div class="card-body">
                <div class="listjs-table" id="customerList">
                    <div class="row g-4 mb-3">


                        <?php if (isset($component)) { $__componentOriginal5329fa4aaef23e5863065f212dba304e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5329fa4aaef23e5863065f212dba304e = $attributes; } ?>
<?php $component = App\View\Components\Permission::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('permission'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Permission::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'roles-create']); ?>
                            <div class="col-sm-auto">
                                <div>
                                    <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-success add-btn" ><i class="ri-add-line align-bottom me-1"></i><?php echo e(__('models.add_role')); ?></a>
                                </div>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $attributes = $__attributesOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__attributesOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $component = $__componentOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__componentOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>



                    </div>

                    <div class="table-responsive table-card mt-3 mb-1">
                        <table class="table align-middle table-nowrap" id="role_table">
                            <thead class="table-light">
                                <tr>

                                    <th class="sort"><?php echo e(__('models.roles')); ?></th>
                                    <th class="sort"><?php echo e(__('models.created_at')); ?></th>
                                    <th class="sort" ><?php echo e(__('models.action')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="list form-check-all">


                            </tbody>
                        </table>






                </div>
            </div><!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('dashboard/assets/js/custom-delete.js')); ?>"></script>

    <script>
        $('#role_table').DataTable({
        processing     : true,
        serverSide     : true ,
        ordering       : false ,
        iDisplayLength : 10 ,
        lengthMenu     : [
                 [10 , 50 , 100 ,  -1] ,
                 [10 , 50 , 100 ,  'All'] ,
        ] ,
        ajax: "<?php echo e(route('admin.get-roles')); ?>",
        columns: [


            {
                data : 'name' ,
                render: function (data, type, full, meta) {
                    return  data ;
                },
            } ,



            {
                data : 'created_at' ,
                render: function (data, type, full, meta) {
                    return '<span class="badge bg-info-subtle text-dark badge-border">' + data + '</span>';
                },
                searchable: false

            } ,

            {
                data : 'action' ,
                searchable: false,
            } ,






        ]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/roles/index.blade.php ENDPATH**/ ?>