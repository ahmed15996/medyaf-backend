<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
   'name' , 'value' , 'label' , 'icon' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
   'name' , 'value' , 'label' , 'icon' => ''
]); ?>
<?php foreach (array_filter(([
   'name' , 'value' , 'label' , 'icon' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>



<div class="custom-control custom-control-primary" style="display: inline-flex;">
    <input type="radio" class="custom-control <?php echo e($name); ?> radio" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" />
    <i class="<?php echo e($icon); ?>"></i> <label class="" for=""><?php echo e($label); ?></label>
</div>



<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/radio.blade.php ENDPATH**/ ?>