<?php if (isset($component)) { $__componentOriginale21568ead3521c9c5905956976bc5d60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale21568ead3521c9c5905956976bc5d60 = $attributes; } ?>
<?php $component = App\View\Components\Hidden::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hidden'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Hidden::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin ? $admin->id : '')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale21568ead3521c9c5905956976bc5d60)): ?>
<?php $attributes = $__attributesOriginale21568ead3521c9c5905956976bc5d60; ?>
<?php unset($__attributesOriginale21568ead3521c9c5905956976bc5d60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale21568ead3521c9c5905956976bc5d60)): ?>
<?php $component = $__componentOriginale21568ead3521c9c5905956976bc5d60; ?>
<?php unset($__componentOriginale21568ead3521c9c5905956976bc5d60); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.name')).'','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin ? $admin->name : '' )]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.email')).'','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin ? $admin->email : '' ),'type' => 'email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb = $attributes; } ?>
<?php $component = App\View\Components\Forms::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Forms::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.password')).'','name' => 'password','type' => 'password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $attributes = $__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__attributesOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb)): ?>
<?php $component = $__componentOriginal76d6344029791d7bdc3c2f20e1a474eb; ?>
<?php unset($__componentOriginal76d6344029791d7bdc3c2f20e1a474eb); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal883fdc89edfbbec46cb517a38fc85736 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal883fdc89edfbbec46cb517a38fc85736 = $attributes; } ?>
<?php $component = App\View\Components\Role::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('role'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Role::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'role_id','label' => ''.e(__('models.roles')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($roles->pluck('name', 'id')),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin?$admin:'')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal883fdc89edfbbec46cb517a38fc85736)): ?>
<?php $attributes = $__attributesOriginal883fdc89edfbbec46cb517a38fc85736; ?>
<?php unset($__attributesOriginal883fdc89edfbbec46cb517a38fc85736); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal883fdc89edfbbec46cb517a38fc85736)): ?>
<?php $component = $__componentOriginal883fdc89edfbbec46cb517a38fc85736; ?>
<?php unset($__componentOriginal883fdc89edfbbec46cb517a38fc85736); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginaleebd0438791cc0f780c9af7786d8bac8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleebd0438791cc0f780c9af7786d8bac8 = $attributes; } ?>
<?php $component = App\View\Components\Image::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Image::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.img')).'','name' => 'img','type' => 'file','id' => 'formFile','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admin?$admin->img:'')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleebd0438791cc0f780c9af7786d8bac8)): ?>
<?php $attributes = $__attributesOriginaleebd0438791cc0f780c9af7786d8bac8; ?>
<?php unset($__attributesOriginaleebd0438791cc0f780c9af7786d8bac8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleebd0438791cc0f780c9af7786d8bac8)): ?>
<?php $component = $__componentOriginaleebd0438791cc0f780c9af7786d8bac8; ?>
<?php unset($__componentOriginaleebd0438791cc0f780c9af7786d8bac8); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/admins/_inputs.blade.php ENDPATH**/ ?>