<?php $__env->startSection('title'); ?>
  <?php echo e(__('models.home')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col">

        <div class="h-100">
            <div class="row mb-3 pb-1">
                <div class="col-12">
                    <div class="d-flex align-items-lg-center flex-lg-row flex-column">
                        <div class="flex-grow-1">
                            <h4 class="fs-16 mb-1"><?php echo e(__('models.good_morning')); ?>, <?php echo e(auth('admin')->user()->name); ?>!</h4>
                            <p class="text-muted mb-0"><?php echo e(__('models.happening')); ?>.</p>
                        </div>

                    </div><!-- end card header -->
                </div>
                <!--end col-->
            </div>
            <!--end row-->

            <div class="row">

                <div class="row">
                    <div class="col-xxl-12">
                        <div class="card">
                            <div class="card-header align-items-center d-flex">
                                <h4 class="card-title mb-0 flex-grow-1"><?php echo e(__('models.party_today')); ?></h4>

                            </div><!-- end card header -->
                            <?php if($parties_today->count() > 0 ): ?>
                                <div class="card-body pt-0">
                                    <ul class="list-group list-group-flush border-dashed">
                                      <?php $__currentLoopData = $parties_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                      <li class="list-group-item ps-0">
                                            <div class="row align-items-center g-3">
                                                <div class="col-auto">
                                                    <div class="avatar-sm p-1 py-2 h-auto bg-light rounded-3 shadow">
                                                        <div class="text-center">
                                                            <h5 class="text-muted"><?php echo e($party->date); ?></h5>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <h5 class="text-muted mt-0 mb-1 fs-13"><?php echo e(Carbon\Carbon::parse($party->time)->format('h:i A')); ?></h5>
                                                    <a href="<?php echo e(route('admin.parties.show' , $party->id)); ?>" class="text-reset fs-14 mb-0"><?php echo e($party->name); ?></a>
                                                </div>
                                                <div class="col-sm-auto">
                                                    <div class="avatar-group">

                                                        <div class="avatar-group-item shadow">
                                                            <a href="javascript: void(0);">
                                                                <div class="avatar-xxs">
                                                                    <span class="avatar-title rounded-circle bg-info text-white">
                                                                        <?php echo e($party->users()->count()); ?>

                                                                    </span>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end row -->
                                        </li><!-- end -->

                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul><!-- end -->

                                </div><!-- end card body -->
                            <?php else: ?>

                            <div class="no_data"> لا توجد مناسبات اليوم</div>
                            <?php endif; ?>
                        </div><!-- end card -->
                    </div><!-- end col -->






                </div>





                <?php if (isset($component)) { $__componentOriginal58366526de7e009dc4c997e0a4bf30a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3 = $attributes; } ?>
<?php $component = App\View\Components\Statics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('statics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Statics::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.roles')).'','color' => 'info','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($roles),'route' => ''.e(route('admin.roles.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $attributes = $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $component = $__componentOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal58366526de7e009dc4c997e0a4bf30a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3 = $attributes; } ?>
<?php $component = App\View\Components\Statics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('statics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Statics::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.admins')).'','color' => 'primary','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($admins),'route' => ''.e(route('admin.admins.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $attributes = $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $component = $__componentOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal58366526de7e009dc4c997e0a4bf30a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3 = $attributes; } ?>
<?php $component = App\View\Components\Statics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('statics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Statics::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.users')).'','color' => 'danger','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users),'route' => ''.e(route('admin.users.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $attributes = $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $component = $__componentOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal58366526de7e009dc4c997e0a4bf30a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3 = $attributes; } ?>
<?php $component = App\View\Components\Statics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('statics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Statics::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.countries')).'','color' => 'success','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($countries),'route' => ''.e(route('admin.countries.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $attributes = $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $component = $__componentOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal58366526de7e009dc4c997e0a4bf30a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3 = $attributes; } ?>
<?php $component = App\View\Components\Statics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('statics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Statics::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.events')).'','color' => 'primary','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($events),'route' => ''.e(route('admin.events.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $attributes = $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $component = $__componentOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal58366526de7e009dc4c997e0a4bf30a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3 = $attributes; } ?>
<?php $component = App\View\Components\Statics::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('statics'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Statics::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e(__('models.parties')).'','color' => 'primary','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($parties),'route' => ''.e(route('admin.parties.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $attributes = $__attributesOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__attributesOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3)): ?>
<?php $component = $__componentOriginal58366526de7e009dc4c997e0a4bf30a3; ?>
<?php unset($__componentOriginal58366526de7e009dc4c997e0a4bf30a3); ?>
<?php endif; ?>



            </div> <!-- end row-->










        </div>

    </div> <!-- end col -->


</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/home.blade.php ENDPATH**/ ?>