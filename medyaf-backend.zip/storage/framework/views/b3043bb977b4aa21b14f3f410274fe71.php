<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'value'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'value'
]); ?>
<?php foreach (array_filter(([
    'value'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="col-md-12 col-12 mb-3">
    <div class="d-flex col-md-12 flex-column mb-7 fv-row fv-plugins-icon-container">
            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                <span class="required" style="font-weight:bold">
                    <?php echo e(__('models.location') . ' ('.__('models.search_in_map').')'); ?>

                </span>

            </label>
                <input type="text"  name="location"  class="form-control form-control-solid" id="searchInput" value="<?php echo e(old('location' , $value->location)); ?>" >

    </div> <br>
</div>

<div class="col-md-12 col-12 mb-3">
    <div class="d-flex col-12 flex-column mb-7 fv-row fv-plugins-icon-container" style="height:100vh">
        <input type="hidden" name="location" class="form-control" id="location"  value="<?php echo e(old('location' , $value->location)); ?>">
        <input type="hidden" name="lat" class="form-control" id="lat"  value="<?php echo e(old('lat' , $value->lat)); ?>">
        <input type="hidden" name="lng" class="form-control" id="lng"  value="<?php echo e(old('lng' , $value->lng)); ?>">
        <div id="map" style="height: 100%;width: 100%;">
    </div>
</div>
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/mab.blade.php ENDPATH**/ ?>