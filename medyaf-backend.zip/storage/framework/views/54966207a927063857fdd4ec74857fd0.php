
<?php
    $country = App\Models\Country::where('id' , $id)->first();
?>
<td>
    <div class="hstack gap-3 flex-wrap">
        <?php if (isset($component)) { $__componentOriginal5329fa4aaef23e5863065f212dba304e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5329fa4aaef23e5863065f212dba304e = $attributes; } ?>
<?php $component = App\View\Components\Permission::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('permission'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Permission::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'countries-update']); ?>
            <a href="<?php echo e(route('admin.countries.edit' , $country->id)); ?>" class="text-primary d-inline-block edit-item-btn"> <i class="ri-pencil-fill fs-16"></i></a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $attributes = $__attributesOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__attributesOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $component = $__componentOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__componentOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal5329fa4aaef23e5863065f212dba304e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5329fa4aaef23e5863065f212dba304e = $attributes; } ?>
<?php $component = App\View\Components\Permission::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('permission'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Permission::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'countries-delete']); ?>
            <a href="<?php echo e(route('admin.countries.destroy' , $country->id )); ?>" data-id="<?php echo e($country->id); ?>" class="text-danger d-inline-block remove-item-btn"><i class="ri-delete-bin-5-fill fs-16"></i></a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $attributes = $__attributesOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__attributesOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $component = $__componentOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__componentOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>
    </div>
</td>




<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/countries/actions.blade.php ENDPATH**/ ?>