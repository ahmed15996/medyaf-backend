<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'route' , 'label' , 'nav_link' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'route' , 'label' , 'nav_link' => ''
]); ?>
<?php foreach (array_filter(([
    'route' , 'label' , 'nav_link' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<li class="nav-item">
    <a href="<?php echo e($route); ?>" class="nav-link <?php echo e($nav_link); ?>" data-key="t-starter"> <?php echo e($label); ?> </a>
</li>


<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/nav-item.blade.php ENDPATH**/ ?>