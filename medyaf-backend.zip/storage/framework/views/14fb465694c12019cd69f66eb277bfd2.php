<?php $__env->startSection('title'); ?>
   <?php echo e(__('models.events')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"></h4>
            </div><!-- end card header -->

            <div class="card-body">
                <div class="listjs-table" id="customerList">
                    <div class="row g-4 mb-3">

                        <?php if (isset($component)) { $__componentOriginal5329fa4aaef23e5863065f212dba304e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5329fa4aaef23e5863065f212dba304e = $attributes; } ?>
<?php $component = App\View\Components\Permission::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('permission'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Permission::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'events-create']); ?>
                            <div class="col-lg-12">
                                <div>
                                    <a href="<?php echo e(route('admin.events.create')); ?>" class="btn btn-success add-btn" ><i class="ri-add-line align-bottom me-1"></i><?php echo e(__('models.add_event')); ?></a>
                                </div>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $attributes = $__attributesOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__attributesOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5329fa4aaef23e5863065f212dba304e)): ?>
<?php $component = $__componentOriginal5329fa4aaef23e5863065f212dba304e; ?>
<?php unset($__componentOriginal5329fa4aaef23e5863065f212dba304e); ?>
<?php endif; ?>


                        <?php if (isset($component)) { $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $attributes; } ?>
<?php $component = App\View\Components\OrderBy::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('order-by'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OrderBy::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '3','name' => 'created_id','label' => ''.e(__('models.order_by')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['asc' => 'الأقدم', 'desc' => 'الأحدث'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $attributes = $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $component = $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $attributes; } ?>
<?php $component = App\View\Components\OrderBy::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('order-by'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OrderBy::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '3','name' => 'price','label' => ''.e(__('models.price')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['asc' => 'الأقل', 'desc' => 'الأعلي'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $attributes = $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $component = $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $attributes; } ?>
<?php $component = App\View\Components\OrderBy::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('order-by'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OrderBy::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '3','name' => 'count','label' => ''.e(__('models.count')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['asc' => 'الأقل', 'desc' => 'الأكبر'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $attributes = $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $component = $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe = $attributes; } ?>
<?php $component = App\View\Components\OrderBy::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('order-by'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OrderBy::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => '3','name' => 'user_events','label' => ''.e(__('models.package')).'','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['asc' => 'الاقل استخداما', 'desc' => 'الاكثر استخداما'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $attributes = $__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__attributesOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe)): ?>
<?php $component = $__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe; ?>
<?php unset($__componentOriginald90cd4a6d2fe1c3a42bfab9e71aa8afe); ?>
<?php endif; ?>

                    </div>

                    <div class="table-responsive table-card mt-3 mb-1">
                        <table class="table align-middle table-nowrap" id="event_table">
                            <thead class="table-light">
                                <tr>

                                    <th class="sort"><?php echo e(__('models.price')); ?></th>
                                    <th class="sort"><?php echo e(__('models.count')); ?></th>
                                    <th class="sort"><?php echo e(__('models.user_events')); ?></th>
                                    <th class="sort"><?php echo e(__('models.created_at')); ?></th>
                                    <th class="sort" ><?php echo e(__('models.action')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="list form-check-all">


                            </tbody>
                        </table>







                    </div>
            </div><!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('dashboard/assets/js/custom-delete.js')); ?>"></script>

    <script>
        var table =  $('#event_table').DataTable({
            processing     : true,
            serverSide     : true ,
            ordering       : false ,
            iDisplayLength : 10 ,
            lengthMenu     : [
                    [10 , 50 , 100 ,  -1] ,
                    [10 , 50 , 100 ,  'All'] ,
            ] ,
            ajax: {
                url: "<?php echo e(route('admin.get-events')); ?>",
                data: function(d) {
                    d.order_by = $('#created_id').val();
                    d.order_price = $('#price').val();
                    d.order_count = $('#count').val();
                    d.order_event = $('#user_events').val();
                }
            },

            columns: [


                {
                    data : 'price' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,

                {
                    data : 'count' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                } ,


                {
                    data : 'event_users' ,
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                    searchable: false
                } ,

                {
                    data: 'created_at',
                    render: function (data, type, full, meta) {
                        return  data ;
                    },
                    searchable: false
                } ,

                {
                    data : 'action' ,
                    searchable: false,
                } ,



            ]
        });

        $('#created_id').on('change', function(e) {
            console.log($(this).val());
            table.draw();
        });

        $('#price').on('change', function(e) {
            console.log($(this).val());
            table.draw();
        });
        $('#count').on('change', function(e) {
            console.log($(this).val());
            table.draw();
        });
        $('#user_events').on('change', function(e) {
            console.log($(this).val());
            table.draw();
        });



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/dashboard/backend/events/index.blade.php ENDPATH**/ ?>