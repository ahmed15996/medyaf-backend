<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([

    'add_module' , 'name_module' , 'route'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([

    'add_module' , 'name_module' , 'route'
]); ?>
<?php foreach (array_filter(([

    'add_module' , 'name_module' , 'route'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>




<div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0"><?php echo e($add_module); ?></h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e($route); ?>"><?php echo e($name_module); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e($add_module); ?></li>
                </ol>
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/content.blade.php ENDPATH**/ ?>