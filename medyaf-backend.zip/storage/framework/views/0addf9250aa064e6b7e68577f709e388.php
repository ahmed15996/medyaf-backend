<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name' , 'icon' => '' , 'active' => ''
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name' , 'icon' => '' , 'active' => ''
]); ?>
<?php foreach (array_filter(([
    'name' , 'icon' => '' , 'active' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<li class="nav-item">
    <a class="nav-link <?php echo e($active); ?> menu-link" href="#<?php echo e($name); ?>" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="<?php echo e($name); ?>">
        <i class="<?php echo e($icon); ?>"></i> <span data-key="t-pages"><?php echo e(__('models.' . $name)); ?></span>
    </a>


    <div class="collapse menu-dropdown" id="<?php echo e($name); ?>">
        <ul class="nav nav-sm flex-column">

            <?php echo e($slot); ?>


        </ul>
    </div>
</li>




<?php /**PATH D:\laragon\www\Saudi Arabia\medyaf-backend\resources\views/components/menu.blade.php ENDPATH**/ ?>