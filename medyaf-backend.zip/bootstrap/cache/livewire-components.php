<?php return array (
  'about-component' => 'App\\Http\\Livewire\\AboutComponent',
  'cart-component' => 'App\\Http\\Livewire\\CartComponent',
  'checkout-component' => 'App\\Http\\Livewire\\CheckoutComponent',
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'count-cart-component' => 'App\\Http\\Livewire\\CountCartComponent',
  'favourite-component' => 'App\\Http\\Livewire\\FavouriteComponent',
  'favourite-products' => 'App\\Http\\Livewire\\FavouriteProducts',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'product-details' => 'App\\Http\\Livewire\\ProductDetails',
  'shop-component' => 'App\\Http\\Livewire\\ShopComponent',
);